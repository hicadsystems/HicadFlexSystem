Alter table fl_agents add status int, exitdate nvarchar(10)

select * from fl_agents